import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Parse JSON bodies
app.use(express.json({ limit: '10mb' }));

// Helper for deterministic fallback suggestions if Gemini API is unavailable or returns an error
function generateFallbackReviews(businessName: string, category: string, description: string) {
  const cat = category || 'local store';
  const name = businessName || 'this business';
  const desc = description.toLowerCase();

  const isCafe = desc.includes('cafe') || desc.includes('coffee') || cat.toLowerCase().includes('cafe');

  if (isCafe) {
    return [
      {
        style: 'Short & Simple',
        text: `Great food and really good service. Had a great experience!`
      },
      {
        style: 'Friendly',
        text: `Really enjoyed the food and the atmosphere. Would definitely visit again.`
      },
      {
        style: 'Detailed',
        text: `Good food, friendly service and a nice comfortable atmosphere. Smooth experience overall.`
      },
      {
        style: 'Highly Recommended',
        text: `Excellent experience with tasty food, great coffee, and quick service. Highly recommended!`
      }
    ];
  }

  let qualityFocus = 'great quality and wonderful service';
  if (desc.includes('food') || desc.includes('cake') || desc.includes('bakery') || desc.includes('flour') || desc.includes('spices')) {
    qualityFocus = 'fresh products and authentic taste';
  } else if (desc.includes('salon') || desc.includes('hair') || desc.includes('spa')) {
    qualityFocus = 'skilled styling and attentive care';
  } else if (desc.includes('gym') || desc.includes('fitness')) {
    qualityFocus = 'well-maintained equipment and motivating environment';
  }

  return [
    {
      style: 'Short & Simple',
      text: `Prompt service and excellent quality at ${name}. Very satisfied!`
    },
    {
      style: 'Friendly',
      text: `Always a pleasant visit to ${name}! The team is courteous and everything is always handled neatly.`
    },
    {
      style: 'Detailed',
      text: `Visited ${name} for their ${cat}. Really impressed by the ${qualityFocus}. Smooth experience and fair pricing. Will definitely return!`
    },
    {
      style: 'Highly Recommended',
      text: `Top notch experience with ${name}! Reliable, fast, and high quality. 10/10 recommended to anyone looking for great service in the area.`
    }
  ];
}

// API: Generate review suggestions using Gemini 3.8 Flash
app.post('/api/generate-reviews', async (req, res) => {
  try {
    const { businessName, category, description } = req.body;

    if (!businessName || !description) {
      return res.status(400).json({ error: 'Business name and description are required.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      console.warn('GEMINI_API_KEY not found in environment, returning tailored fallback suggestions.');
      const fallbacks = generateFallbackReviews(businessName, category, description);
      return res.json({ suggestions: fallbacks });
    }

    console.log(`Generating reviews for "${businessName}"... API key present: ${Boolean(apiKey)}`);

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const prompt = `
You are generating authentic, natural-sounding Google review suggestions for customers of a local business.
Customers will scan a QR code at the business counter and choose one of these suggestions to copy and submit as their Google review.

Business Details:
- Name: "${businessName}"
- Category: "${category || 'Local Business'}"
- Offerings/Description: "${description}"

CRITICAL RULES:
1. Generate exactly 4 review suggestions, each corresponding to one of these styles:
   - "Short & Simple" (15-25 words: punchy, direct, positive)
   - "Friendly" (20-35 words: warm, pleasant, approachable)
   - "Detailed" (35-50 words: mentions specific services/items from the description, quality, value)
   - "Highly Recommended" (25-40 words: enthusiastic, reliable recommendation)
2. NEVER invent highly specific fictitious claims that were not provided in the description (do NOT invent staff names or untrue stories).
3. Keep the tone natural, genuine, and written from a real customer's perspective.
4. Do not use generic buzzwords or overly poetic hyperbole.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an expert copywriter creating truthful, helpful review templates for local business customers.',
        temperature: 0.7,
        thinkingConfig: {
          thinkingLevel: 'LOW' as any,
        },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  style: {
                    type: Type.STRING,
                    description: 'The style label: Short & Simple, Friendly, Detailed, or Highly Recommended',
                  },
                  text: {
                    type: Type.STRING,
                    description: 'The suggested review text written in first person.',
                  },
                },
                required: ['style', 'text'],
              },
            },
          },
          required: ['suggestions'],
        },
      },
    });

    const text = response.text;
    console.log('Gemini returned response text:', text);

    if (!text) {
      throw new Error('Empty response from Gemini API');
    }

    const parsed = JSON.parse(text);
    if (!parsed.suggestions || !Array.isArray(parsed.suggestions) || parsed.suggestions.length === 0) {
      throw new Error('Invalid suggestions structure from Gemini API');
    }

    return res.json({ suggestions: parsed.suggestions });
  } catch (error: any) {
    console.error('Error generating AI review suggestions:', error.message || error);
    // Provide safe, high-quality fallback suggestions so user experience is smooth
    const { businessName, category, description } = req.body;
    const fallbacks = generateFallbackReviews(businessName, category, description);
    return res.json({
      suggestions: fallbacks,
      fallbackUsed: true,
      errorDetail: error.message || String(error),
      notice: 'Generated using local templates due to temporary AI service timeout.'
    });
  }
});

// App configuration endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'ReviewQR', timestamp: new Date().toISOString() });
});

async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`ReviewQR server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
