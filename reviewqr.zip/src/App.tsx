import React, { useState, useRef, useEffect } from 'react';
import {
  QrCode,
  FileImage,
  FileText,
  Printer,
  Smartphone,
  ShieldCheck,
  Check,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { BusinessData } from './types';
import { DEMO_BUSINESS_DATA } from './utils/themes';
import { GeneratorForm } from './components/GeneratorForm';
import { PosterPreview } from './components/PosterPreview';
import { CustomerSimulatorModal } from './components/CustomerSimulatorModal';
import { CustomerReviewPage } from './components/CustomerReviewPage';
import { InvalidReviewPage } from './components/InvalidReviewPage';
import { decodeBusinessData, getReviewUrl } from './utils/codec';
import { exportPosterAsPng, exportPosterAsPdf } from './utils/export';

export const App: React.FC = () => {
  const [businessData, setBusinessData] = useState<BusinessData>(DEMO_BUSINESS_DATA);
  const [isMobileSimulatorOpen, setIsMobileSimulatorOpen] = useState(false);

  // Export action statuses
  const [pngStatus, setPngStatus] = useState<'idle' | 'generating' | 'downloaded' | 'error'>('idle');
  const [pdfStatus, setPdfStatus] = useState<'idle' | 'generating' | 'downloaded' | 'error'>('idle');
  const [printStatus, setPrintStatus] = useState<'idle' | 'opening' | 'error'>('idle');
  const [toastMessage, setToastMessage] = useState<{ text: string; isError: boolean } | null>(null);

  // References
  const previewPosterRef = useRef<HTMLDivElement>(null);
  const exportCardRef = useRef<HTMLDivElement>(null);

  // Toast feedback helper
  const showToast = (text: string, isError = false) => {
    setToastMessage({ text, isError });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Client-side routing based on URL path or hash
  const [currentPath, setCurrentPath] = useState(window.location.pathname);
  const [routeEncodedData, setRouteEncodedData] = useState<string | null>(null);

  useEffect(() => {
    const handleUrlChange = () => {
      const pathname = window.location.pathname;
      const searchParams = new URLSearchParams(window.location.search);
      const hash = window.location.hash;

      let encoded: string | null = null;

      if (pathname.startsWith('/review/')) {
        encoded = pathname.replace('/review/', '').trim();
      } else if (searchParams.has('review')) {
        encoded = searchParams.get('review');
      } else if (hash.startsWith('#/review/')) {
        encoded = hash.replace('#/review/', '').trim();
      }

      setCurrentPath(pathname);
      setRouteEncodedData(encoded);
    };

    handleUrlChange();
    window.addEventListener('popstate', handleUrlChange);
    return () => window.removeEventListener('popstate', handleUrlChange);
  }, []);

  // Navigate helper
  const navigateTo = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    if (path === '/') {
      setRouteEncodedData(null);
    }
  };

  // If URL has review data, render the customer review page or invalid notice
  if (routeEncodedData) {
    const decoded = decodeBusinessData(routeEncodedData);

    if (!decoded) {
      return (
        <InvalidReviewPage
          onGoToGenerator={() => navigateTo('/')}
          onLoadDemo={() => {
            const demoUrl = getReviewUrl(DEMO_BUSINESS_DATA);
            window.location.href = demoUrl;
          }}
        />
      );
    }

    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
        <CustomerReviewPage businessData={decoded} />
        {/* Subtle footer */}
        <footer className="py-4 text-center text-xs text-slate-400 border-t border-slate-100">
          Powered by ReviewQR • Smart Customer Experience
        </footer>
      </div>
    );
  }

  // Quick export handlers using the dedicated high-res export canvas
  const handleDownloadPng = async () => {
    const target = exportCardRef.current || previewPosterRef.current;
    if (!target) return;
    setPngStatus('generating');
    try {
      await exportPosterAsPng(target, businessData.name || 'Counter-Card');
      setPngStatus('downloaded');
      setTimeout(() => setPngStatus('idle'), 2500);
    } catch (err: any) {
      console.error('Error exporting PNG:', err);
      setPngStatus('error');
      showToast(err?.message || "Couldn't generate the PNG. Please try again.", true);
      setTimeout(() => setPngStatus('idle'), 3000);
    }
  };

  const handleDownloadPdf = async () => {
    const target = exportCardRef.current || previewPosterRef.current;
    if (!target) return;
    setPdfStatus('generating');
    try {
      await exportPosterAsPdf(target, businessData.name || 'Counter-Card');
      setPdfStatus('downloaded');
      setTimeout(() => setPdfStatus('idle'), 2500);
    } catch (err: any) {
      console.error('Error exporting PDF:', err);
      setPdfStatus('error');
      showToast(err?.message || "Couldn't generate the PDF. Please try again.", true);
      setTimeout(() => setPdfStatus('idle'), 3000);
    }
  };

  const handlePrint = () => {
    setPrintStatus('opening');
    try {
      window.print();
    } catch (err) {
      showToast("Couldn't open print dialog. Please try again.", true);
    } finally {
      setTimeout(() => setPrintStatus('idle'), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col justify-between relative">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div
          role="alert"
          className={`fixed top-4 right-4 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl shadow-xl border text-sm font-bold transition-all animate-in fade-in slide-in-from-top-3 ${
            toastMessage.isError
              ? 'bg-rose-50 border-rose-200 text-rose-800 shadow-rose-900/10'
              : 'bg-emerald-50 border-emerald-200 text-emerald-800 shadow-emerald-900/10'
          }`}
        >
          {toastMessage.isError ? (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          ) : (
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Top Application Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-8 py-3.5 no-print">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-800 text-white flex items-center justify-center shadow-md shadow-indigo-600/25">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-black tracking-tight text-slate-900">
                  ReviewQR
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-50 text-[#1A73E8] border border-blue-200/60">
                  Counter Card Maker
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium hidden sm:block">
                Create a smart review QR for any business.
              </p>
            </div>
          </div>

          {/* Header Action Controls */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsMobileSimulatorOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-800 text-xs sm:text-sm font-bold transition-all shadow-2xs cursor-pointer active:scale-95"
              title="Test the mobile customer scan and one-tap review flow"
            >
              <Smartphone className="w-4 h-4 text-indigo-600" />
              <span className="hidden sm:inline">Simulate Scan</span>
              <span className="sm:hidden">Test</span>
            </button>

            <button
              onClick={handleDownloadPng}
              disabled={pngStatus === 'generating'}
              className="inline-flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold transition-all shadow-sm shadow-blue-500/20 active:scale-95 cursor-pointer disabled:opacity-60"
            >
              {pngStatus === 'generating' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Generating...</span>
                </>
              ) : pngStatus === 'downloaded' ? (
                <>
                  <Check className="w-4 h-4 text-emerald-300" />
                  <span>Downloaded ✓</span>
                </>
              ) : (
                <>
                  <FileImage className="w-4 h-4" />
                  <span className="hidden sm:inline">Download PNG</span>
                  <span className="sm:hidden">PNG</span>
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Studio Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 no-print">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Generator Form (7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <GeneratorForm
              businessData={businessData}
              setBusinessData={setBusinessData}
              posterElementRef={exportCardRef}
              onOpenMobilePreview={() => setIsMobileSimulatorOpen(true)}
            />
          </div>

          {/* Right Column: Live Poster Preview (5 cols) */}
          <div className="lg:col-span-5 sticky top-20 flex flex-col gap-4">
            <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-sm border border-slate-200/90 no-print">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <span>Live Print Card Preview</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-blue-100 text-blue-800 font-bold">
                      Counter Card
                    </span>
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Physical tabletop / acrylic stand display
                  </p>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleDownloadPng}
                    disabled={pngStatus === 'generating'}
                    className={`p-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      pngStatus === 'generating'
                        ? 'bg-blue-100 text-blue-700'
                        : pngStatus === 'downloaded'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                    title={
                      pngStatus === 'generating'
                        ? 'Generating PNG...'
                        : pngStatus === 'downloaded'
                        ? 'Downloaded PNG!'
                        : 'Download 2400x3120 PNG'
                    }
                  >
                    {pngStatus === 'generating' ? (
                      <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                    ) : pngStatus === 'downloaded' ? (
                      <Check className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <FileImage className="w-4 h-4 text-emerald-600" />
                    )}
                  </button>

                  <button
                    onClick={handleDownloadPdf}
                    disabled={pdfStatus === 'generating'}
                    className={`p-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      pdfStatus === 'generating'
                        ? 'bg-rose-100 text-rose-700'
                        : pdfStatus === 'downloaded'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                    title={
                      pdfStatus === 'generating'
                        ? 'Generating PDF...'
                        : pdfStatus === 'downloaded'
                        ? 'Downloaded PDF!'
                        : 'Download A4 PDF'
                    }
                  >
                    {pdfStatus === 'generating' ? (
                      <Loader2 className="w-4 h-4 animate-spin text-rose-600" />
                    ) : pdfStatus === 'downloaded' ? (
                      <Check className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <FileText className="w-4 h-4 text-rose-600" />
                    )}
                  </button>

                  <button
                    onClick={handlePrint}
                    className={`p-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      printStatus === 'opening'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                    title={printStatus === 'opening' ? 'Opening print dialog...' : 'Print Counter Card'}
                  >
                    {printStatus === 'opening' ? (
                      <Loader2 className="w-4 h-4 animate-spin text-amber-600" />
                    ) : (
                      <Printer className="w-4 h-4 text-slate-700" />
                    )}
                  </button>
                </div>
              </div>

              {/* Responsive Preview Stage: Contains entire card with zero clipping */}
              <div className="w-full flex justify-center items-center bg-slate-100/80 p-4 sm:p-6 rounded-2xl border border-slate-200/60 min-h-[520px]">
                <div className="w-full max-w-[390px] flex justify-center">
                  <PosterPreview
                    businessData={businessData}
                    posterRef={previewPosterRef}
                    isExportVariant={false}
                  />
                </div>
              </div>

              {/* Quick Info & Tips */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1 text-[11px]">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>High-contrast QR quiet zones</span>
                </span>
                <button
                  type="button"
                  onClick={() => setIsMobileSimulatorOpen(true)}
                  className="text-[11px] font-bold text-indigo-600 hover:underline cursor-pointer"
                >
                  Test Customer Scan →
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* OFFSCREEN DEDICATED HIGH-RES EXPORT CARD (800x1040px canonical size at position 0,0) */}
      <div
        id="reviewqr-export-container"
        aria-hidden="true"
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '800px',
          minHeight: '1040px',
          pointerEvents: 'none',
          zIndex: -9999,
          opacity: 1,
          overflow: 'visible',
        }}
      >
        <div ref={exportCardRef} className="w-[800px]">
          <PosterPreview
            businessData={businessData}
            isExportVariant={true}
          />
        </div>
      </div>

      {/* DEDICATED NATIVE PRINT CONTAINER */}
      <div id="reviewqr-print-root">
        <div className="w-[720px] max-w-full">
          <PosterPreview
            businessData={businessData}
            isExportVariant={true}
            className="shadow-none border border-slate-300"
          />
        </div>
      </div>

      {/* Interactive Mobile Customer Simulation Modal */}
      <CustomerSimulatorModal
        isOpen={isMobileSimulatorOpen}
        businessData={businessData}
        onClose={() => setIsMobileSimulatorOpen(false)}
      />

      {/* Footer */}
      <footer className="mt-auto py-5 border-t border-slate-200/80 text-center text-xs text-slate-400 no-print">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>ReviewQR • Google Review Counter Display Card Maker</span>
          <span>Single-User Local Utility • Privacy First</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
