/**
 * Robust URL validation helper
 * Accepts standard http:// and https:// URLs
 * Rejects empty strings and malformed URLs safely without throwing
 */
export function isValidUrl(value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim();
  if (!trimmed) return false;

  try {
    const url = new URL(trimmed);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}
