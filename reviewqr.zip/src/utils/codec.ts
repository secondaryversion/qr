import { BusinessData, EncodedReviewData, PosterThemeId } from '../types';

// Convert string to base64url safely supporting Unicode / UTF-8
export function toBase64Url(str: string): string {
  try {
    const bytes = new TextEncoder().encode(str);
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary)
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  } catch (err) {
    console.error('Error encoding to base64url:', err);
    return encodeURIComponent(str);
  }
}

// Convert base64url back to string safely supporting Unicode / UTF-8
export function fromBase64Url(str: string): string {
  try {
    let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
    while (base64.length % 4) {
      base64 += '=';
    }
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new TextDecoder().decode(bytes);
  } catch (err) {
    console.error('Error decoding from base64url:', err);
    return decodeURIComponent(str);
  }
}

// Compact the business data to minimize QR payload size
// Never embed large base64 images in QR URL to keep QR scannable & well within QR limits
export function encodeBusinessData(data: BusinessData): string {
  // Store logo in sessionStorage if available so same-device testing displays logo seamlessly
  if (typeof window !== 'undefined' && data.logo && data.name) {
    try {
      sessionStorage.setItem(`rqr_logo_${data.name.trim()}`, data.logo);
    } catch {
      // Ignore quota errors
    }
  }

  const payload: EncodedReviewData = {
    n: data.name ? data.name.trim() : 'Business',
    c: data.category ? data.category.trim() : '',
    d: data.description ? data.description.trim().slice(0, 150) : '',
    g: data.googleReviewUrl ? data.googleReviewUrl.trim() : '',
    i: data.instagramUrl?.trim() || undefined,
    w: data.websiteUrl?.trim() || undefined,
    t: data.theme || 'classic-slate',
    h: data.headline?.trim() || undefined,
    s: (data.suggestions || []).map((s) => ({
      s: s.style || 'Feedback',
      t: s.text,
    })),
  };

  const jsonString = JSON.stringify(payload);
  return toBase64Url(jsonString);
}

// Decode business data from URL parameter
export function decodeBusinessData(encoded: string): BusinessData | null {
  try {
    const jsonString = fromBase64Url(encoded);
    const payload = JSON.parse(jsonString) as Partial<EncodedReviewData>;

    if (!payload.n || !payload.g) {
      return null;
    }

    // Try to retrieve local cached logo if available on same machine
    let logo = '';
    if (typeof window !== 'undefined') {
      try {
        logo = sessionStorage.getItem(`rqr_logo_${payload.n.trim()}`) || '';
      } catch {
        logo = '';
      }
    }

    const businessData: BusinessData = {
      name: payload.n,
      category: payload.c || '',
      description: payload.d || '',
      googleReviewUrl: payload.g,
      instagramUrl: payload.i || '',
      websiteUrl: payload.w || '',
      theme: (payload.t as PosterThemeId) || 'classic-slate',
      headline: payload.h || 'REVIEW US ON GOOGLE',
      subheadline: 'Scan with your phone to leave us a Google review',
      showLogo: true,
      showInstagram: Boolean(payload.i),
      showWebsite: Boolean(payload.w),
      showCategory: Boolean(payload.c),
      logo,
      suggestions: (payload.s || []).map((s, index) => {
        if (typeof s === 'string') {
          const styles = ['Short & Simple', 'Friendly', 'Detailed', 'Highly Recommended'];
          return {
            id: `sug-${index + 1}`,
            style: styles[index % styles.length],
            text: s,
          };
        }
        return {
          id: `sug-${index + 1}`,
          style: s.s || 'Feedback',
          text: s.t,
        };
      }),
    };

    return businessData;
  } catch (err) {
    console.error('Failed to parse encoded business data:', err);
    return null;
  }
}

// Generate the full review URL that the QR code will point to
export function getReviewUrl(businessData: BusinessData): string {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const encoded = encodeBusinessData(businessData);
  return `${origin}/review/${encoded}`;
}
