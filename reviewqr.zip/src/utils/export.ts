import { toCanvas } from 'html-to-image';
import { jsPDF } from 'jspdf';

/**
 * Sanitizes business name for clean, safe filenames across all operating systems
 * e.g., "Anuj Aata Chakki" -> "Anuj-Aata-Chakki"
 */
export function sanitizeFileName(name: string): string {
  if (!name || typeof name !== 'string') return 'ReviewQR';
  const clean = name
    .trim()
    .replace(/[^a-zA-Z0-9\s_-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 50);
  return clean || 'ReviewQR';
}

/**
 * Asynchronously waits for all fonts, QR codes, logos, and images within an element
 * to finish downloading and decoding into browser memory before rasterization.
 */
export async function waitForAssets(element: HTMLElement): Promise<void> {
  // 1. Wait for document fonts if browser supports FontFaceSet
  try {
    if (typeof document !== 'undefined' && document.fonts && document.fonts.ready) {
      await document.fonts.ready;
    }
  } catch (err) {
    console.warn('Font readiness check skipped:', err);
  }

  // 2. Wait for all <img> tags inside element to complete loading and decoding
  const images = Array.from(element.querySelectorAll('img'));
  if (images.length > 0) {
    const promises = images.map((img) => {
      // Force eager loading so off-screen elements are not skipped by browser lazy-loader
      if (img.loading === 'lazy') {
        img.loading = 'eager';
      }

      // If already complete and has natural dimensions, decode if possible
      if (img.complete && img.naturalWidth > 0) {
        if (typeof img.decode === 'function') {
          return img.decode().catch(() => {});
        }
        return Promise.resolve();
      }

      return new Promise<void>((resolve) => {
        const timer = setTimeout(() => {
          resolve(); // Guarantee timeout safety: never hang export
        }, 3000);

        const onDone = () => {
          clearTimeout(timer);
          if (typeof img.decode === 'function') {
            img.decode().then(resolve).catch(resolve);
          } else {
            resolve();
          }
        };

        img.onload = onDone;
        img.onerror = () => {
          clearTimeout(timer);
          resolve(); // Safe fallback: continue even if an individual asset fails
        };
      });
    });

    await Promise.all(promises);
  }

  // 3. Small flush tick for layout tree and CSS transforms
  await new Promise((r) => setTimeout(r, 80));
}

/**
 * Cross-browser file download using Blob and Object URL with automatic cleanup
 */
export function triggerBlobDownload(blob: Blob, filename: string): void {
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.style.display = 'none';
  link.href = objectUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  // Revoke object URL after download triggers to prevent memory leaks
  setTimeout(() => {
    URL.revokeObjectURL(objectUrl);
  }, 3000);
}

/**
 * Generates a master high-resolution HTML5 Canvas from the dedicated card element (2400 x 3120px)
 */
export async function getHighResCardCanvas(element: HTMLElement): Promise<HTMLCanvasElement> {
  // Ensure all fonts, QR codes, and images are fully decoded
  await waitForAssets(element);

  const safeWidth = Math.max(element.scrollWidth || element.offsetWidth || 800, 200);
  const safeHeight = Math.max(element.scrollHeight || element.offsetHeight || 1040, 200);

  // pixelRatio: 3 produces 2400 x 3120px from canonical 800 x 1040px design
  const canvas = await toCanvas(element, {
    width: safeWidth,
    height: safeHeight,
    pixelRatio: 3,
    backgroundColor: '#FFFFFF',
    skipFonts: true, // Prevents CORS SecurityError on foreign stylesheet cssRules
    cacheBust: false,
    style: {
      transform: 'none',
      margin: '0',
      top: '0',
      left: '0',
    },
  });

  return canvas;
}

/**
 * Exports dedicated card to master print-ready PNG (2400 x 3120px)
 */
export async function exportPosterAsPng(element: HTMLElement, fileName: string): Promise<void> {
  try {
    const canvas = await getHighResCardCanvas(element);

    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((b) => {
        if (b) {
          resolve(b);
        } else {
          reject(new Error('Failed to generate PNG blob from high-resolution canvas.'));
        }
      }, 'image/png', 1.0);
    });

    const safeName = sanitizeFileName(fileName);
    triggerBlobDownload(blob, `${safeName}-Google-Review-QR.png`);
  } catch (error: any) {
    console.error('Failed to export PNG:', error);
    throw new Error(error?.message || "Couldn't generate the PNG. Please try again.");
  }
}

/**
 * Exports dedicated card to high-resolution A4 Portrait PDF with 15mm margins and zero clipping
 */
export async function exportPosterAsPdf(element: HTMLElement, fileName: string): Promise<void> {
  try {
    // 1. Render high-resolution canvas data
    const canvas = await getHighResCardCanvas(element);
    const dataUrl = canvas.toDataURL('image/png', 1.0);

    const cardWidth = canvas.width;
    const cardHeight = canvas.height;

    // 2. Standard A4 portrait dimensions in mm: 210 x 297
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const pageWidth = 210;
    const pageHeight = 297;
    // Standard printable 15mm safe margins
    const margin = 15;
    const printableWidth = pageWidth - margin * 2; // 180mm
    const printableHeight = pageHeight - margin * 2; // 267mm

    // 3. Calculate exact proportional contain dimensions to prevent any distortion or cropping
    const cardRatio = cardHeight / cardWidth;
    const printableRatio = printableHeight / printableWidth;

    let renderWidth: number;
    let renderHeight: number;

    if (cardRatio > printableRatio) {
      // Proportionally taller: fit to available printable height
      renderHeight = printableHeight;
      renderWidth = printableHeight / cardRatio;
    } else {
      // Proportionally wider: fit to available printable width
      renderWidth = printableWidth;
      renderHeight = printableWidth * cardRatio;
    }

    // 4. Center horizontally and vertically within A4 printable area
    const xOffset = margin + (printableWidth - renderWidth) / 2;
    const yOffset = margin + (printableHeight - renderHeight) / 2;

    pdf.addImage(dataUrl, 'PNG', xOffset, yOffset, renderWidth, renderHeight, undefined, 'FAST');

    // 5. Download PDF via Blob to ensure full compatibility
    const pdfBlob = pdf.output('blob');
    const safeName = sanitizeFileName(fileName);
    triggerBlobDownload(pdfBlob, `${safeName}-Google-Review-QR.pdf`);
  } catch (error: any) {
    console.error('Failed to export PDF:', error);
    throw new Error(error?.message || "Couldn't generate the PDF. Please try again.");
  }
}
