import QRCode from 'qrcode';

export interface QRGenerationOptions {
  width?: number;
  margin?: number;
  color?: {
    dark: string;
    light: string;
  };
  errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
}

/**
 * Generate a high-resolution DataURL for a QR code with multi-tier fallback
 */
export async function generateQrDataUrl(
  text: string,
  options: QRGenerationOptions = {}
): Promise<string> {
  const {
    width = 600,
    margin = 2,
    color = { dark: '#000000', light: '#FFFFFF' },
    errorCorrectionLevel = 'M',
  } = options;

  if (!text || typeof text !== 'string') {
    throw new Error('Empty QR text provided');
  }

  // Tier 1: Try PNG DataURL with requested errorCorrectionLevel
  try {
    return await QRCode.toDataURL(text, {
      width,
      margin,
      color,
      errorCorrectionLevel,
    });
  } catch (err1) {
    console.warn(`QR toDataURL failed with level ${errorCorrectionLevel}, retrying with level 'L'...`, err1);
  }

  // Tier 2: Try with Error Correction 'L' (lowest density requirement)
  try {
    return await QRCode.toDataURL(text, {
      width,
      margin,
      color,
      errorCorrectionLevel: 'L',
    });
  } catch (err2) {
    console.warn("QR toDataURL level 'L' failed, retrying with SVG format...", err2);
  }

  // Tier 3: Try pure SVG string and convert to DataURL
  try {
    const svg = await QRCode.toString(text, {
      type: 'svg',
      margin,
      color,
      errorCorrectionLevel: 'L',
    });
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  } catch (err3) {
    console.error('All QR generation attempts failed for text:', text.slice(0, 100), err3);
    throw new Error('Failed to generate QR code.');
  }
}

/**
 * Generate an SVG string representation of the QR code
 */
export async function generateQrSvg(
  text: string,
  options: QRGenerationOptions = {}
): Promise<string> {
  const {
    margin = 2,
    color = { dark: '#000000', light: '#FFFFFF' },
    errorCorrectionLevel = 'M',
  } = options;

  try {
    return await QRCode.toString(text, {
      type: 'svg',
      margin,
      color,
      errorCorrectionLevel,
    });
  } catch {
    return await QRCode.toString(text, {
      type: 'svg',
      margin,
      color,
      errorCorrectionLevel: 'L',
    });
  }
}
