import { PosterTheme, PosterThemeId, BusinessData } from '../types';

export const POSTER_THEMES: Record<PosterThemeId, PosterTheme> = {
  'classic-slate': {
    id: 'classic-slate',
    name: 'Google Clean (Standard)',
    tagline: 'Google-inspired blue accent with crisp white counter card look',
    bgGradient: 'from-white to-slate-50',
    bgSolid: '#FFFFFF',
    cardBg: '#FFFFFF',
    borderColor: '#E8EAED',
    accentColor: '#1A73E8', // Google Blue
    accentLight: '#E8F0FE',
    textColor: '#202124',
    textMuted: '#5F6368',
    qrFg: '#000000',
    qrBg: '#FFFFFF',
    badgeBg: '#E8F0FE',
    badgeText: '#1A73E8',
    buttonGradient: 'from-blue-600 to-blue-700',
  },
  'warm-ochre': {
    id: 'warm-ochre',
    name: 'Artisan Warm',
    tagline: 'Warm terracotta & honey amber for bakeries, food & cafes',
    bgGradient: 'from-amber-50/40 via-white to-orange-50/30',
    bgSolid: '#FFFDF9',
    cardBg: '#FFF8F0',
    borderColor: '#EFE5D8',
    accentColor: '#B45309',
    accentLight: '#FEF3C7',
    textColor: '#451A03',
    textMuted: '#78350F',
    qrFg: '#000000',
    qrBg: '#FFFFFF',
    badgeBg: '#FEF3C7',
    badgeText: '#92400E',
    buttonGradient: 'from-amber-700 to-amber-900',
  },
  'emerald-luxury': {
    id: 'emerald-luxury',
    name: 'Emerald Luxe',
    tagline: 'Botanical emerald & gold for salons, jewellery & boutique hotels',
    bgGradient: 'from-emerald-50/40 via-white to-teal-50/40',
    bgSolid: '#FAFCFA',
    cardBg: '#F2F8F4',
    borderColor: '#D1E7DD',
    accentColor: '#0F766E',
    accentLight: '#D1FAE5',
    textColor: '#064E3B',
    textMuted: '#047857',
    qrFg: '#000000',
    qrBg: '#FFFFFF',
    badgeBg: '#D1FAE5',
    badgeText: '#065F46',
    buttonGradient: 'from-emerald-800 to-teal-950',
  },
  'royal-indigo': {
    id: 'royal-indigo',
    name: 'Modern Studio',
    tagline: 'Cobalt and sleek typography for fitness studios & tech stores',
    bgGradient: 'from-indigo-50/50 via-white to-slate-50',
    bgSolid: '#FFFFFF',
    cardBg: '#F5F7FF',
    borderColor: '#E0E7FF',
    accentColor: '#4F46E5',
    accentLight: '#EEF2FF',
    textColor: '#1E1B4B',
    textMuted: '#4338CA',
    qrFg: '#000000',
    qrBg: '#FFFFFF',
    badgeBg: '#EEF2FF',
    badgeText: '#3730A3',
    buttonGradient: 'from-indigo-700 to-indigo-950',
  },
  'minimal-mono': {
    id: 'minimal-mono',
    name: 'Pure Monochrome',
    tagline: 'Architectural black & white, high-contrast and ink-saving',
    bgGradient: 'from-white to-neutral-50',
    bgSolid: '#FFFFFF',
    cardBg: '#FAFAFA',
    borderColor: '#E5E5E5',
    accentColor: '#171717',
    accentLight: '#F5F5F5',
    textColor: '#111827',
    textMuted: '#6B7280',
    qrFg: '#000000',
    qrBg: '#FFFFFF',
    badgeBg: '#F3F4F6',
    badgeText: '#111827',
    buttonGradient: 'from-black to-neutral-900',
  },
};

export const CATEGORY_OPTIONS = [
  'Restaurant',
  'Cafe',
  'Bakery',
  'Salon',
  'Boutique',
  'Jewellery',
  'Hotel',
  'Gym',
  'Grocery',
  'Local Store',
  'Flour Mill',
  'Spa & Wellness',
  'Other',
];

/**
 * Returns a business-specific heading tailored to category
 */
export function getDefaultHeadlineForCategory(category: string): string {
  const cat = (category || '').trim().toLowerCase();
  if (cat.includes('cafe')) return 'CHECK US OUT ON GOOGLE';
  if (cat.includes('restaurant')) return 'ENJOYED YOUR MEAL? REVIEW US ON GOOGLE';
  if (cat.includes('bakery')) return 'LOVED OUR BAKES? REVIEW US ON GOOGLE';
  if (cat.includes('salon')) return 'LOVED YOUR LOOK? REVIEW US ON GOOGLE';
  if (cat.includes('boutique') || cat.includes('jewellery')) return 'LOVED YOUR EXPERIENCE? REVIEW US ON GOOGLE';
  if (cat.includes('hotel')) return 'ENJOYED YOUR STAY? REVIEW US ON GOOGLE';
  if (cat.includes('flour mill') || cat.includes('store') || cat.includes('grocery')) return 'HAPPY WITH OUR SERVICE? REVIEW US ON GOOGLE';
  if (cat.includes('gym') || cat.includes('fitness')) return 'CRUSHED YOUR WORKOUT? REVIEW US ON GOOGLE';
  if (cat.includes('spa') || cat.includes('wellness')) return 'LOVED YOUR RELAXATION? REVIEW US ON GOOGLE';
  return 'CHECK US OUT ON GOOGLE';
}

// Clean Cafe placeholder logo data URL (SVG with coffee cup / steam)
const CAFE_LOGO_SVG = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none"><rect width="100" height="100" rx="24" fill="%231A73E8"/><path d="M28 42h38v24a14 14 0 01-14 14H42a14 14 0 01-14-14V42z" fill="white"/><path d="M66 48h6a7 7 0 017 7v2a7 7 0 01-7 7h-6v-16z" stroke="white" stroke-width="5" stroke-linecap="round"/><path d="M38 24c0 4-3 6-3 10m12-10c0 4-3 6-3 10m12-10c0 4-3 6-3 10" stroke="white" stroke-width="4" stroke-linecap="round"/></svg>`;

export const DEMO_BUSINESS_DATA: BusinessData = {
  name: 'CAZZ CAFE',
  category: 'Cafe',
  description: 'Casual cafe serving coffee, snacks and meals in a comfortable atmosphere.',
  googleReviewUrl: 'https://www.google.com/maps/search/?api=1&query=Cazz+Cafe',
  instagramUrl: 'https://www.instagram.com/cazzcafe',
  websiteUrl: 'https://example.com',
  logo: CAFE_LOGO_SVG,
  theme: 'classic-slate',
  headline: 'CHECK US OUT ON GOOGLE',
  subheadline: 'Scan with your phone to leave us a Google review',
  showLogo: true,
  showInstagram: true,
  showWebsite: true,
  showCategory: true,
  suggestions: [
    {
      id: 'demo-1',
      style: 'Short & Simple',
      text: 'Great food and really good service. Had a great experience!',
    },
    {
      id: 'demo-2',
      style: 'Friendly',
      text: 'Really enjoyed the food and the atmosphere. Would definitely visit again.',
    },
    {
      id: 'demo-3',
      style: 'Detailed',
      text: 'Good food, friendly service and a nice comfortable atmosphere. Smooth experience overall.',
    },
    {
      id: 'demo-4',
      style: 'Highly Recommended',
      text: 'Excellent experience with tasty food, great coffee, and quick service. Highly recommended!',
    },
  ],
};
