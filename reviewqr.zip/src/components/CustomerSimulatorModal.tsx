import React from 'react';
import { X, Smartphone, ExternalLink, QrCode } from 'lucide-react';
import { BusinessData } from '../types';
import { CustomerReviewPage } from './CustomerReviewPage';
import { getReviewUrl } from '../utils/codec';

interface CustomerSimulatorModalProps {
  businessData: BusinessData;
  isOpen: boolean;
  onClose: () => void;
}

export const CustomerSimulatorModal: React.FC<CustomerSimulatorModalProps> = ({
  businessData,
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const reviewUrl = getReviewUrl(businessData);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl shadow-2xl border border-slate-700/80 p-4 sm:p-6 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-white">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-600/30 text-indigo-400">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white">
                Customer Mobile Preview
              </h3>
              <p className="text-[11px] text-slate-400">
                This is what customers see upon scanning the physical counter poster QR
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Realistic Mobile Device Frame */}
        <div className="my-auto py-3 flex justify-center items-center overflow-y-auto">
          <div className="relative w-[340px] sm:w-[370px] h-[640px] bg-slate-950 rounded-[44px] p-3 shadow-2xl border-4 border-slate-800 ring-1 ring-slate-700/50 flex flex-col">
            {/* Phone Speaker & Dynamic Island Notch */}
            <div className="absolute top-4 inset-x-0 mx-auto w-24 h-4 bg-slate-900 rounded-full flex items-center justify-center gap-1.5 z-20">
              <div className="w-2 h-2 rounded-full bg-slate-800" />
              <div className="w-8 h-1 rounded-full bg-slate-800" />
            </div>

            {/* Phone Screen Area */}
            <div className="w-full h-full bg-slate-50 rounded-[34px] overflow-y-auto pt-6 flex flex-col scrollbar-thin">
              <CustomerReviewPage
                businessData={businessData}
                isSimulator={true}
              />
            </div>

            {/* Phone Bottom Home Bar */}
            <div className="absolute bottom-1 inset-x-0 mx-auto w-32 h-1 bg-slate-600/60 rounded-full pointer-events-none" />
          </div>
        </div>

        {/* Modal Footer with Direct Link */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 truncate max-w-[240px]">
            <QrCode className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="truncate text-[11px] font-mono text-slate-400">{reviewUrl}</span>
          </div>
          <a
            href={reviewUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors"
          >
            <span>Open in New Tab</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
