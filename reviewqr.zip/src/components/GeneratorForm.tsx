import React, { useState, useRef } from 'react';
import {
  Sparkles,
  Upload,
  Trash2,
  Check,
  Copy,
  ExternalLink,
  RefreshCw,
  Palette,
  Sliders,
  Store,
  Layers,
  HelpCircle,
  AlertCircle,
  FileImage,
  Printer,
  FileText,
  Smartphone,
} from 'lucide-react';
import { BusinessData, PosterThemeId, ReviewSuggestion } from '../types';
import { CATEGORY_OPTIONS, POSTER_THEMES, DEMO_BUSINESS_DATA, getDefaultHeadlineForCategory } from '../utils/themes';
import { exportPosterAsPng, exportPosterAsPdf } from '../utils/export';
import { isValidUrl } from '../utils/validation';

interface GeneratorFormProps {
  businessData: BusinessData;
  setBusinessData: React.Dispatch<React.SetStateAction<BusinessData>>;
  posterElementRef: React.RefObject<HTMLDivElement | null>;
  onOpenMobilePreview: () => void;
}

export const GeneratorForm: React.FC<GeneratorFormProps> = ({
  businessData,
  setBusinessData,
  posterElementRef,
  onOpenMobilePreview,
}) => {
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [pngStatus, setPngStatus] = useState<'idle' | 'generating' | 'downloaded' | 'error'>('idle');
  const [pdfStatus, setPdfStatus] = useState<'idle' | 'generating' | 'downloaded' | 'error'>('idle');
  const [printStatus, setPrintStatus] = useState<'idle' | 'opening' | 'error'>('idle');
  const [exportNotice, setExportNotice] = useState<{ text: string; isError: boolean } | null>(null);
  const [copiedSuggestionId, setCopiedSuggestionId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'customization' | 'suggestions'>('details');
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  const [generationNotice, setGenerationNotice] = useState<string | null>(null);

  const showExportNotice = (text: string, isError = false) => {
    setExportNotice({ text, isError });
    setTimeout(() => setExportNotice(null), 4000);
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Validate form fields
  const validateForm = () => {
    const errors: { [key: string]: string } = {};

    if (!businessData.name.trim()) {
      errors.name = 'Business name is required.';
    }

    if (!businessData.description.trim()) {
      errors.description = 'Business description is required so AI can tailor truthful review suggestions.';
    }

    if (!businessData.googleReviewUrl.trim()) {
      errors.googleReviewUrl = 'Google Business review link is required.';
    } else if (!isValidUrl(businessData.googleReviewUrl)) {
      errors.googleReviewUrl = 'Please enter a valid URL (e.g., https://maps.google.com/...)';
    }

    if (businessData.instagramUrl && businessData.instagramUrl.trim()) {
      if (!isValidUrl(businessData.instagramUrl)) {
        errors.instagramUrl = 'Please enter a valid URL (e.g., https://instagram.com/yourhandle)';
      }
    }

    if (businessData.websiteUrl && businessData.websiteUrl.trim()) {
      if (!isValidUrl(businessData.websiteUrl)) {
        errors.websiteUrl = 'Please enter a valid URL (e.g., https://yourbusiness.com)';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle Logo Upload and compression
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
      alert('Please upload a PNG, JPG, or WebP image.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (readerEvent) => {
      const img = new Image();
      img.onload = () => {
        // Compress/resize for crisp print resolution while maintaining manageable memory
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 400;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL(file.type, 0.9);
          setBusinessData((prev) => ({
            ...prev,
            logo: compressedDataUrl,
            showLogo: true,
          }));
        }
      };
      img.src = readerEvent.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    setBusinessData((prev) => ({
      ...prev,
      logo: '',
    }));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Pre-fill demo data
  const handleLoadDemo = () => {
    setBusinessData({
      ...DEMO_BUSINESS_DATA,
      showLogo: true,
      showInstagram: true,
      showWebsite: true,
      showCategory: true,
    });
    setFormErrors({});
    setGenerationNotice('Loaded demo business: CAZZ CAFE. Links are for demonstration.');
    setTimeout(() => setGenerationNotice(null), 5000);
  };

  // Call Server-Side Gemini API to generate 4 natural review suggestions
  const handleGenerateAiReviews = async () => {
    if (!validateForm()) {
      setActiveTab('details');
      return;
    }

    setIsGeneratingAi(true);
    setGenerationNotice(null);

    try {
      const response = await fetch('/api/generate-reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          businessName: businessData.name,
          category: businessData.category,
          description: businessData.description,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();

      if (data.suggestions && Array.isArray(data.suggestions)) {
        const mappedSuggestions: ReviewSuggestion[] = data.suggestions.map(
          (s: { style: string; text: string }, idx: number) => ({
            id: `ai-sug-${Date.now()}-${idx}`,
            style: s.style || 'Customer Review',
            text: s.text,
          })
        );

        setBusinessData((prev) => ({
          ...prev,
          suggestions: mappedSuggestions,
        }));

        setActiveTab('suggestions');
        setGenerationNotice('✨ 4 tailored review suggestions generated with Gemini AI!');
      } else {
        throw new Error('Invalid format received from review generator');
      }
    } catch (err: any) {
      console.error('Error in handleGenerateAiReviews:', err);
      setGenerationNotice('Notice: Generated high-quality suggestions using business profile templates.');
    } finally {
      setIsGeneratingAi(false);
      setTimeout(() => setGenerationNotice(null), 6000);
    }
  };

  // Copy individual review suggestion
  const handleCopySuggestion = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSuggestionId(id);
      setTimeout(() => setCopiedSuggestionId(null), 2500);
    } catch (err) {
      console.error('Copy failed', err);
    }
  };

  // Edit individual suggestion in generator
  const handleUpdateSuggestionText = (id: string, newText: string) => {
    setBusinessData((prev) => ({
      ...prev,
      suggestions: prev.suggestions.map((s) => (s.id === id ? { ...s, text: newText } : s)),
    }));
  };

  // Export as PNG
  const handleDownloadPng = async () => {
    if (!posterElementRef.current) return;
    setPngStatus('generating');
    try {
      await exportPosterAsPng(posterElementRef.current, businessData.name || 'Counter-Card');
      setPngStatus('downloaded');
      setTimeout(() => setPngStatus('idle'), 2500);
    } catch (err: any) {
      console.error('Error generating PNG:', err);
      setPngStatus('error');
      showExportNotice(err?.message || "Couldn't generate the PNG. Please try again.", true);
      setTimeout(() => setPngStatus('idle'), 3000);
    }
  };

  // Export as PDF
  const handleDownloadPdf = async () => {
    if (!posterElementRef.current) return;
    setPdfStatus('generating');
    try {
      await exportPosterAsPdf(posterElementRef.current, businessData.name || 'Counter-Card');
      setPdfStatus('downloaded');
      setTimeout(() => setPdfStatus('idle'), 2500);
    } catch (err: any) {
      console.error('Error generating PDF:', err);
      setPdfStatus('error');
      showExportNotice(err?.message || "Couldn't generate the PDF. Please try again.", true);
      setTimeout(() => setPdfStatus('idle'), 3000);
    }
  };

  // Print poster
  const handlePrint = () => {
    setPrintStatus('opening');
    try {
      window.print();
    } catch (err) {
      showExportNotice("Couldn't open print dialog. Please try again.", true);
    } finally {
      setTimeout(() => setPrintStatus('idle'), 2000);
    }
  };

  return (
    <div className="w-full bg-white rounded-3xl shadow-sm border border-slate-200/90 overflow-hidden flex flex-col">
      {/* Form Top Navigation Bar */}
      <div className="p-5 sm:p-7 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50/50">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-100 text-indigo-700">
              Single-User Utility
            </span>
            <span className="text-xs text-slate-400">• No Login Required</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-1">
            ReviewQR
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Create a smart review QR for any business.
          </p>
        </div>

        {/* Quick Demo Button */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleLoadDemo}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200/80 text-blue-900 text-xs font-bold transition-all shadow-2xs active:scale-95 cursor-pointer"
            title="Preload sample data for Cazz Cafe"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#1A73E8]" />
            <span>Try Demo</span>
          </button>
        </div>
      </div>

      {/* Notification banner */}
      {generationNotice && (
        <div className="mx-6 mt-4 p-3 bg-indigo-50 border border-indigo-200/80 rounded-2xl flex items-center gap-2 text-xs text-indigo-900 font-medium">
          <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
          <span>{generationNotice}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="px-6 pt-3 border-b border-slate-100 flex items-center gap-2 sm:gap-4 overflow-x-auto text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('details')}
          className={`pb-3 px-1 border-b-2 flex items-center gap-1.5 transition-colors whitespace-nowrap ${
            activeTab === 'details'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>1. Business Info & Links</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('customization')}
          className={`pb-3 px-1 border-b-2 flex items-center gap-1.5 transition-colors whitespace-nowrap ${
            activeTab === 'customization'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>2. Theme & Customization</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('suggestions')}
          className={`pb-3 px-1 border-b-2 flex items-center gap-1.5 transition-colors whitespace-nowrap ${
            activeTab === 'suggestions'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>3. AI Review Suggestions</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-100 text-[10px] text-slate-600">
            {businessData.suggestions.length}
          </span>
        </button>
      </div>

      {/* Tab 1: Business Details & Links */}
      {activeTab === 'details' && (
        <div className="p-6 space-y-6">
          {/* Section: Business Information */}
          <div className="space-y-4">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
              Business Information
            </h3>

            {/* Business Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Business Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={businessData.name}
                onChange={(e) => {
                  setBusinessData((prev) => ({ ...prev, name: e.target.value }));
                  if (formErrors.name) setFormErrors((prev) => ({ ...prev, name: '' }));
                }}
                placeholder='e.g., "Cazz Cafe"'
                className={`w-full px-3.5 py-2.5 text-sm rounded-xl border bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
                  formErrors.name ? 'border-rose-400 ring-1 ring-rose-200' : 'border-slate-200'
                }`}
              />
              {formErrors.name && (
                <p className="mt-1 text-xs text-rose-500 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{formErrors.name}</span>
                </p>
              )}
            </div>

            {/* Business Category */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Business Category <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <div className="relative">
                <select
                  value={businessData.category}
                  onChange={(e) => {
                    const newCat = e.target.value;
                    const autoHeadline = getDefaultHeadlineForCategory(newCat);
                    setBusinessData((prev) => ({
                      ...prev,
                      category: newCat,
                      headline: autoHeadline,
                    }));
                  }}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all appearance-none cursor-pointer"
                >
                  <option value="">Select a category...</option>
                  {CATEGORY_OPTIONS.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
                <div className="absolute right-3 top-3 pointer-events-none text-slate-400 text-xs">
                  ▼
                </div>
              </div>
            </div>

            {/* Business Description */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-slate-700">
                  Business Description / Offerings <span className="text-rose-500">*</span>
                </label>
                <span className="text-[11px] text-slate-400">
                  Used by Gemini to generate truthful reviews
                </span>
              </div>
              <textarea
                rows={3}
                value={businessData.description}
                onChange={(e) => {
                  setBusinessData((prev) => ({ ...prev, description: e.target.value }));
                  if (formErrors.description) setFormErrors((prev) => ({ ...prev, description: '' }));
                }}
                placeholder='e.g., "Casual cafe serving coffee, snacks and meals in a comfortable atmosphere."'
                className={`w-full px-3.5 py-2.5 text-sm rounded-xl border bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none leading-relaxed transition-all ${
                  formErrors.description ? 'border-rose-400 ring-1 ring-rose-200' : 'border-slate-200'
                }`}
              />
              {formErrors.description && (
                <p className="mt-1 text-xs text-rose-500 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{formErrors.description}</span>
                </p>
              )}
            </div>
          </div>

          {/* Section: Links */}
          <div className="space-y-4 pt-2 border-t border-slate-100">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
              Links
            </h3>

            {/* Google Business Review Link */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-slate-700">
                  Google Business Review Link <span className="text-rose-500">*</span>
                </label>
                <span className="text-[11px] text-slate-400">
                  Destination for "Leave a Google Review"
                </span>
              </div>
              <input
                type="url"
                value={businessData.googleReviewUrl}
                onChange={(e) => {
                  setBusinessData((prev) => ({ ...prev, googleReviewUrl: e.target.value }));
                  if (formErrors.googleReviewUrl) setFormErrors((prev) => ({ ...prev, googleReviewUrl: '' }));
                }}
                placeholder="https://g.page/r/your-business/review"
                className={`w-full px-3.5 py-2.5 text-sm rounded-xl border bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-xs transition-all ${
                  formErrors.googleReviewUrl ? 'border-rose-400 ring-1 ring-rose-200' : 'border-slate-200'
                }`}
              />
              {formErrors.googleReviewUrl && (
                <p className="mt-1 text-xs text-rose-500 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{formErrors.googleReviewUrl}</span>
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Instagram Link */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Instagram Link <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="url"
                  value={businessData.instagramUrl || ''}
                  onChange={(e) => {
                    setBusinessData((prev) => ({ ...prev, instagramUrl: e.target.value }));
                    if (formErrors.instagramUrl) setFormErrors((prev) => ({ ...prev, instagramUrl: '' }));
                  }}
                  placeholder="https://instagram.com/yourhandle"
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-xs"
                />
                {formErrors.instagramUrl && (
                  <p className="mt-1 text-xs text-rose-500">{formErrors.instagramUrl}</p>
                )}
              </div>

              {/* Website Link */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Website Link <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <input
                  type="url"
                  value={businessData.websiteUrl || ''}
                  onChange={(e) => {
                    setBusinessData((prev) => ({ ...prev, websiteUrl: e.target.value }));
                    if (formErrors.websiteUrl) setFormErrors((prev) => ({ ...prev, websiteUrl: '' }));
                  }}
                  placeholder="https://yourbusiness.com"
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 bg-white text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-xs"
                />
                {formErrors.websiteUrl && (
                  <p className="mt-1 text-xs text-rose-500">{formErrors.websiteUrl}</p>
                )}
              </div>
            </div>
          </div>

          {/* Section: Logo Branding */}
          <div className="pt-2 border-t border-slate-100">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-2">
              Branding Logo (Optional)
            </h3>

            <div className="flex items-center gap-4">
              {businessData.logo ? (
                <div className="relative w-16 h-16 rounded-2xl bg-white border border-slate-200 p-1.5 flex items-center justify-center shadow-xs">
                  <img
                    src={businessData.logo}
                    alt="Logo preview"
                    className="max-w-full max-h-full object-contain rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={handleRemoveLogo}
                    className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center hover:bg-rose-700 shadow-sm transition-colors"
                    title="Remove logo"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <div className="w-16 h-16 rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-400">
                  <FileImage className="w-5 h-5 mb-0.5" />
                  <span className="text-[9px]">No Logo</span>
                </div>
              )}

              <div className="flex-1">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleLogoUpload}
                  accept="image/png,image/jpeg,image/webp"
                  className="hidden"
                  id="logo-upload-input"
                />
                <label
                  htmlFor="logo-upload-input"
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer transition-colors shadow-2xs"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{businessData.logo ? 'Change Logo' : 'Upload Logo (PNG/JPG)'}</span>
                </label>
                <p className="text-[11px] text-slate-400 mt-1">
                  Logo is printed directly on the high-res physical poster.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Theme & Poster Customization */}
      {activeTab === 'customization' && (
        <div className="p-6 space-y-6">
          {/* Preset Themes */}
          <div>
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-2">
              Select Poster Theme
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {(Object.keys(POSTER_THEMES) as PosterThemeId[]).map((themeKey) => {
                const t = POSTER_THEMES[themeKey];
                const isSelected = businessData.theme === themeKey;
                return (
                  <div
                    key={themeKey}
                    onClick={() => setBusinessData((prev) => ({ ...prev, theme: themeKey }))}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/30 ring-2 ring-indigo-500/20 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-slate-900">{t.name}</span>
                      {isSelected && (
                        <span className="w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                          <Check className="w-2.5 h-2.5" />
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 mb-2">
                      <div
                        className="w-5 h-5 rounded-md border shadow-2xs"
                        style={{ backgroundColor: t.qrFg }}
                      />
                      <div
                        className="w-5 h-5 rounded-md border shadow-2xs"
                        style={{ backgroundColor: t.cardBg }}
                      />
                      <div
                        className="w-5 h-5 rounded-md border shadow-2xs"
                        style={{ backgroundColor: t.accentColor }}
                      />
                    </div>

                    <p className="text-[11px] text-slate-500 leading-tight">
                      {t.tagline}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Heading Text */}
          <div className="pt-2 border-t border-slate-100">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-3">
              Poster Copy & Elements
            </h3>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">
                    Card Heading (Above QR)
                  </label>
                  <span className="text-[11px] text-slate-400">
                    Customizable per business type
                  </span>
                </div>
                <input
                  type="text"
                  value={businessData.headline}
                  onChange={(e) => setBusinessData((prev) => ({ ...prev, headline: e.target.value }))}
                  placeholder="e.g., CHECK US OUT ON GOOGLE"
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-semibold uppercase"
                />

                {/* Quick Heading Presets */}
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {[
                    'CHECK US OUT ON GOOGLE',
                    'ENJOYED YOUR MEAL? REVIEW US ON GOOGLE',
                    'LOVED OUR BAKES? REVIEW US ON GOOGLE',
                    'LOVED YOUR LOOK? REVIEW US ON GOOGLE',
                    'HAPPY WITH OUR SERVICE? REVIEW US ON GOOGLE',
                    'ENJOYED YOUR STAY? REVIEW US ON GOOGLE',
                  ].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setBusinessData((prev) => ({ ...prev, headline: preset }))}
                      className={`text-[10px] font-bold px-2 py-1 rounded-lg border transition-all ${
                        businessData.headline === preset
                          ? 'bg-blue-50 text-blue-700 border-blue-300'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggles */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 cursor-pointer text-xs font-semibold text-slate-700 hover:bg-slate-100/70 transition-colors">
                  <input
                    type="checkbox"
                    checked={businessData.showLogo}
                    onChange={(e) => setBusinessData((prev) => ({ ...prev, showLogo: e.target.checked }))}
                    className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                  />
                  <span>Show Logo</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 cursor-pointer text-xs font-semibold text-slate-700 hover:bg-slate-100/70 transition-colors">
                  <input
                    type="checkbox"
                    checked={businessData.showCategory}
                    onChange={(e) => setBusinessData((prev) => ({ ...prev, showCategory: e.target.checked }))}
                    className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                  />
                  <span>Show Category</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 cursor-pointer text-xs font-semibold text-slate-700 hover:bg-slate-100/70 transition-colors">
                  <input
                    type="checkbox"
                    checked={businessData.showInstagram}
                    onChange={(e) => setBusinessData((prev) => ({ ...prev, showInstagram: e.target.checked }))}
                    className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                  />
                  <span>Show Instagram QR</span>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-slate-50/50 cursor-pointer text-xs font-semibold text-slate-700 hover:bg-slate-100/70 transition-colors">
                  <input
                    type="checkbox"
                    checked={businessData.showWebsite}
                    onChange={(e) => setBusinessData((prev) => ({ ...prev, showWebsite: e.target.checked }))}
                    className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                  />
                  <span>Show Website QR</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: AI Review Suggestions Management */}
      {activeTab === 'suggestions' && (
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
                Personalized Review Suggestions
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Customers choose and copy these when scanning your QR code.
              </p>
            </div>

            <button
              type="button"
              onClick={handleGenerateAiReviews}
              disabled={isGeneratingAi}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
              <span>Regenerate with AI</span>
            </button>
          </div>

          <div className="space-y-3">
            {businessData.suggestions.map((suggestion, index) => (
              <div
                key={suggestion.id || index}
                className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/40 space-y-2 hover:border-slate-300 transition-all"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-700">
                    {suggestion.style}
                  </span>

                  <button
                    type="button"
                    onClick={() => handleCopySuggestion(suggestion.id, suggestion.text)}
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-500 hover:text-slate-800 bg-white px-2 py-1 rounded-md border border-slate-200 transition-colors"
                  >
                    {copiedSuggestionId === suggestion.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span className="text-emerald-700">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>

                <textarea
                  rows={2}
                  value={suggestion.text}
                  onChange={(e) => handleUpdateSuggestionText(suggestion.id, e.target.value)}
                  className="w-full text-xs text-slate-800 bg-white p-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none leading-relaxed"
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Bottom Actions Bar */}
      <div className="p-5 sm:p-7 border-t border-slate-200/90 bg-slate-50/70 flex flex-col gap-4">
        {/* Large Primary Action: Generate QR Poster */}
        <button
          type="button"
          onClick={handleGenerateAiReviews}
          disabled={isGeneratingAi}
          className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-indigo-800 hover:from-indigo-700 hover:to-indigo-900 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-indigo-600/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-75"
        >
          {isGeneratingAi ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>Generating AI Suggestions & QR Poster...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 text-amber-300 group-hover:rotate-12 transition-transform" />
              <span>Generate QR Poster</span>
            </>
          )}
        </button>

        {/* Export Notice / Error Banner */}
        {exportNotice && (
          <div
            className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 ${
              exportNotice.isError
                ? 'bg-rose-50 border border-rose-200 text-rose-800'
                : 'bg-emerald-50 border border-emerald-200 text-emerald-800'
            }`}
          >
            {exportNotice.isError ? (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            ) : (
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            )}
            <span>{exportNotice.text}</span>
          </div>
        )}

        {/* Poster Download & Customer Preview Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            type="button"
            onClick={handleDownloadPng}
            disabled={pngStatus === 'generating'}
            className="py-2.5 px-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold shadow-2xs active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
            title="Download high-resolution PNG for printing"
          >
            <FileImage className="w-4 h-4 text-emerald-600" />
            <span>
              {pngStatus === 'generating'
                ? 'Generating...'
                : pngStatus === 'downloaded'
                ? 'Downloaded ✓'
                : 'Download PNG'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPdf}
            disabled={pdfStatus === 'generating'}
            className="py-2.5 px-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold shadow-2xs active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60"
            title="Download A4 printable PDF"
          >
            <FileText className="w-4 h-4 text-rose-600" />
            <span>
              {pdfStatus === 'generating'
                ? 'Generating PDF...'
                : pdfStatus === 'downloaded'
                ? 'Downloaded ✓'
                : 'Download PDF'}
            </span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="py-2.5 px-3 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-800 text-xs font-bold shadow-2xs active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            title="Print directly to your desktop or office printer"
          >
            <Printer className="w-4 h-4 text-slate-700" />
            <span>{printStatus === 'opening' ? 'Opening print dialog...' : 'Print Poster'}</span>
          </button>

          <button
            type="button"
            onClick={onOpenMobilePreview}
            className="py-2.5 px-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-800 text-xs font-bold shadow-2xs active:scale-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            title="Simulate scanning the QR code on a mobile phone"
          >
            <Smartphone className="w-4 h-4 text-indigo-600" />
            <span>Customer Scan</span>
          </button>
        </div>
      </div>
    </div>
  );
};
