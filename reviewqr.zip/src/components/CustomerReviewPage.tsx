import React, { useState } from 'react';
import {
  Star,
  Check,
  ExternalLink,
  Edit3,
  Sparkles,
  Instagram,
  Globe,
  Store,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';
import { BusinessData, ReviewSuggestion } from '../types';
import { POSTER_THEMES } from '../utils/themes';

interface CustomerReviewPageProps {
  businessData: BusinessData;
  onBackToGenerator?: () => void;
  isSimulator?: boolean;
}

export const CustomerReviewPage: React.FC<CustomerReviewPageProps> = ({
  businessData,
  onBackToGenerator,
  isSimulator = false,
}) => {
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);
  const [customReviewText, setCustomReviewText] = useState<string>('');
  const [isRedirecting, setIsRedirecting] = useState<boolean>(false);
  const [clipboardError, setClipboardError] = useState<string | null>(null);

  const theme = POSTER_THEMES[businessData.theme] || POSTER_THEMES['classic-slate'];

  // Safe clipboard copy function adhering to mobile requirements
  const copyToClipboard = async (text: string): Promise<boolean> => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        return true;
      }
      // Fallback using execCommand
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.opacity = '0';
      textArea.style.left = '-9999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      const success = document.execCommand('copy');
      document.body.removeChild(textArea);
      return success;
    } catch (err) {
      console.warn('Clipboard permission error:', err);
      return false;
    }
  };

  // Immediate 1-tap review flow:
  // 1. Copy exact review text to clipboard
  // 2. Show toast: "Review copied! Paste it into Google's review box."
  // 3. Immediately redirect to Google Review URL
  const handleUseReview = async (suggestion: ReviewSuggestion) => {
    setSelectedId(suggestion.id);
    setIsRedirecting(true);
    setClipboardError(null);

    const copySuccess = await copyToClipboard(suggestion.text);

    if (!copySuccess) {
      setClipboardError("Couldn't copy automatically. Please copy the review manually.");
    }

    setToastMessage("Review copied! Paste it into Google's review box.");

    const targetUrl = businessData.googleReviewUrl;
    if (targetUrl) {
      if (isSimulator) {
        setTimeout(() => {
          window.open(targetUrl, '_blank', 'noopener,noreferrer');
          setIsRedirecting(false);
        }, 500);
      } else {
        setTimeout(() => {
          window.location.href = targetUrl;
        }, 400);
      }
    }
  };

  // Custom written review flow:
  // Copies custom text and redirects to Google Review URL
  const handleCustomReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const textToCopy = customReviewText.trim();
    if (!textToCopy) return;

    setIsRedirecting(true);
    setClipboardError(null);

    const copySuccess = await copyToClipboard(textToCopy);
    if (!copySuccess) {
      setClipboardError("Couldn't copy automatically. Please copy the review manually.");
    }

    setToastMessage("Review copied! Paste it into Google's review box.");

    const targetUrl = businessData.googleReviewUrl;
    if (targetUrl) {
      if (isSimulator) {
        setTimeout(() => {
          window.open(targetUrl, '_blank', 'noopener,noreferrer');
          setIsRedirecting(false);
        }, 500);
      } else {
        setTimeout(() => {
          window.location.href = targetUrl;
        }, 400);
      }
    }
  };

  // Helper icons/emojis for suggestion styles
  const getStyleEmoji = (index: number) => {
    switch (index % 4) {
      case 0:
        return '⭐';
      case 1:
        return '😊';
      case 2:
        return '✨';
      case 3:
        return '🙌';
      default:
        return '⭐';
    }
  };

  return (
    <div
      className={`min-h-screen w-full flex flex-col items-center justify-start py-4 px-3 sm:px-6 transition-colors duration-200 relative ${
        isSimulator ? 'bg-transparent py-2 px-1' : 'bg-slate-50'
      }`}
      style={{ fontFamily: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif" }}
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`${
            isSimulator ? 'sticky top-2 inset-x-2' : 'fixed top-4 inset-x-4'
          } max-w-sm mx-auto z-50 animate-in slide-in-from-top-3 fade-in duration-200 mb-2`}
        >
          <div className="bg-[#202124] text-white px-4 py-3.5 rounded-2xl shadow-2xl border border-slate-700/80 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
              <Check className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div className="flex-1 text-left">
              <p className="text-xs font-bold text-white leading-tight">
                {toastMessage}
              </p>
              <p className="text-[10px] text-slate-300 mt-0.5 flex items-center gap-1">
                <span>Opening Google Review page...</span>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Clipboard Permission Warning (if permission fails) */}
      {clipboardError && (
        <div className="w-full max-w-md mb-2 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>{clipboardError}</span>
        </div>
      )}

      {/* Top Bar for Back button if testing in generator */}
      {onBackToGenerator && !isSimulator && (
        <div className="w-full max-w-md mb-3 flex items-center justify-between text-xs text-slate-500">
          <button
            onClick={onBackToGenerator}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 shadow-2xs hover:bg-slate-50 font-semibold text-slate-700 transition-colors"
          >
            ← Back to Generator
          </button>
          <span className="bg-blue-50 text-blue-700 border border-blue-200/50 px-2.5 py-0.5 rounded-full font-bold text-[11px]">
            Mobile Review Page
          </span>
        </div>
      )}

      {/* Mobile-First Customer Review Card */}
      <div
        className={`w-full max-w-md bg-white rounded-3xl shadow-md border border-slate-200/90 overflow-hidden flex flex-col ${
          isSimulator ? 'border-none shadow-none rounded-2xl' : ''
        }`}
      >
        {/* Top Header & Business Details */}
        <div className="relative px-5 pt-6 pb-5 text-center border-b border-slate-100 bg-gradient-to-b from-blue-50/30 to-white">
          {/* Business Logo */}
          <div className="flex justify-center mb-2.5">
            {businessData.showLogo && businessData.logo ? (
              <div className="w-16 h-16 rounded-2xl bg-white p-1.5 shadow-xs border border-slate-200 flex items-center justify-center overflow-hidden">
                <img
                  src={businessData.logo}
                  alt={businessData.name}
                  className="max-w-full max-h-full object-contain"
                />
              </div>
            ) : (
              <div className="w-14 h-14 rounded-2xl bg-blue-50 text-[#1A73E8] border border-blue-200/60 flex items-center justify-center font-bold text-xl shadow-xs">
                {businessData.name ? businessData.name.charAt(0).toUpperCase() : <Store className="w-6 h-6" />}
              </div>
            )}
          </div>

          {/* Business Name */}
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight uppercase">
            {businessData.name || 'CAZZ CAFE'}
          </h1>

          {/* Category Badge */}
          {businessData.category && (
            <div className="mt-1 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-slate-100 text-slate-600">
              <Sparkles className="w-3 h-3 text-[#1A73E8]" />
              <span>{businessData.category}</span>
            </div>
          )}

          {/* 5 Stars */}
          <div className="mt-2.5 flex items-center justify-center gap-1 text-[#FBBC04]">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-current stroke-current" />
            ))}
          </div>

          {/* Main Question & Subtitle */}
          <div className="mt-3">
            <h2 className="text-lg sm:text-xl font-black text-slate-900">
              How was your experience?
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Choose a suggestion or write your own.
            </p>
          </div>
        </div>

        {/* 4 AI-Generated Suggestion Cards */}
        <div className="p-4 sm:p-5 flex flex-col gap-3">
          {businessData.suggestions && businessData.suggestions.length > 0 ? (
            businessData.suggestions.map((suggestion, index) => {
              const isChosen = selectedId === suggestion.id && isRedirecting;

              return (
                <div
                  key={suggestion.id || index}
                  className={`w-full p-4 rounded-2xl border transition-all text-left flex flex-col justify-between gap-3 ${
                    isChosen
                      ? 'border-emerald-500 bg-emerald-50/70 shadow-md ring-2 ring-emerald-500/30'
                      : 'border-slate-200 bg-white hover:border-blue-400 hover:bg-slate-50/60 shadow-2xs'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <span className="text-base select-none shrink-0 mt-0.5">
                      {getStyleEmoji(index)}
                    </span>
                    <p className="text-sm text-slate-800 leading-snug font-medium">
                      "{suggestion.text}"
                    </p>
                  </div>

                  {/* Large touch-friendly button: [ Use this review ] */}
                  <button
                    type="button"
                    onClick={() => handleUseReview(suggestion)}
                    disabled={isRedirecting}
                    className={`w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 active:scale-[0.98] transition-all cursor-pointer shadow-xs ${
                      isChosen
                        ? 'bg-emerald-600 text-white'
                        : 'bg-[#1A73E8] hover:bg-blue-700 text-white shadow-blue-500/20'
                    }`}
                  >
                    {isChosen ? (
                      <>
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Copied! Opening Google...</span>
                      </>
                    ) : (
                      <>
                        <span>Use this review</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              );
            })
          ) : (
            <p className="text-xs text-slate-500 text-center py-4">
              No suggestions loaded. You can write your own review below!
            </p>
          )}

          {/* WRITE YOUR OWN REVIEW SECTION */}
          {!isCustomMode ? (
            <button
              type="button"
              onClick={() => setIsCustomMode(true)}
              className="w-full mt-1 py-3 px-4 rounded-2xl border border-dashed border-slate-300 text-slate-700 hover:border-blue-400 hover:bg-blue-50/40 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs"
            >
              <Edit3 className="w-4 h-4 text-[#1A73E8]" />
              <span>Write your own review</span>
            </button>
          ) : (
            <form
              onSubmit={handleCustomReviewSubmit}
              className="mt-2 bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3 animate-in fade-in"
            >
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Edit3 className="w-4 h-4 text-[#1A73E8]" />
                  <span>Write your own review</span>
                </label>
                <button
                  type="button"
                  onClick={() => setIsCustomMode(false)}
                  className="text-xs text-slate-400 hover:text-slate-600 font-semibold"
                >
                  Cancel
                </button>
              </div>

              <textarea
                rows={3}
                value={customReviewText}
                onChange={(e) => setCustomReviewText(e.target.value)}
                placeholder="Share your experience with this business..."
                className="w-full text-xs sm:text-sm bg-white p-3 rounded-xl border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#1A73E8] resize-none leading-relaxed"
                autoFocus
              />

              <button
                type="submit"
                disabled={!customReviewText.trim() || isRedirecting}
                className="w-full py-3 px-4 rounded-xl bg-[#1A73E8] hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer active:scale-[0.98]"
              >
                <Check className="w-4 h-4" />
                <span>Copy & Continue to Google</span>
              </button>
            </form>
          )}

          {/* Social Links if present */}
          {(businessData.instagramUrl || businessData.websiteUrl) && (
            <div className="mt-2 pt-3 border-t border-slate-100 flex items-center justify-center gap-4 text-xs text-slate-500">
              {businessData.instagramUrl && (
                <a
                  href={businessData.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 hover:text-pink-600 transition-colors font-medium"
                >
                  <Instagram className="w-3.5 h-3.5 text-pink-600" />
                  <span>Instagram</span>
                </a>
              )}
              {businessData.instagramUrl && businessData.websiteUrl && <span>•</span>}
              {businessData.websiteUrl && (
                <a
                  href={businessData.websiteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 hover:text-blue-600 transition-colors font-medium"
                >
                  <Globe className="w-3.5 h-3.5 text-blue-600" />
                  <span>Website</span>
                </a>
              )}
            </div>
          )}
        </div>

        {/* Bottom Helpful Note */}
        <div className="bg-slate-50/80 px-4 py-3 border-t border-slate-100 text-center">
          <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
            Tapping <strong>"Use this review"</strong> copies the text. On Google's page, long-press to <strong>Paste</strong> and tap your star rating!
          </p>
        </div>
      </div>
    </div>
  );
};
