import React, { useEffect, useState } from 'react';
import { Star, Instagram, Globe } from 'lucide-react';
import { BusinessData } from '../types';
import { POSTER_THEMES } from '../utils/themes';
import { generateQrDataUrl } from '../utils/qr';
import { getReviewUrl } from '../utils/codec';
import { isValidUrl } from '../utils/validation';

interface PosterPreviewProps {
  businessData: BusinessData;
  posterRef?: React.RefObject<HTMLDivElement | null>;
  className?: string;
  isExportVariant?: boolean;
}

// Official Google Multicolor Wordmark SVG
export const GoogleWordmark: React.FC<{ className?: string }> = ({ className = 'h-6 sm:h-7' }) => (
  <svg viewBox="0 0 272 92" className={className} aria-label="Google">
    <path
      fill="#EA4335"
      d="M115.75 47.18c0 12.77-9.99 22.18-22.25 22.18s-22.25-9.41-22.25-22.18c0-12.85 9.99-22.18 22.25-22.18s22.25 9.32 22.25 22.18zm-9.74 0c0-7.98-5.79-13.44-12.51-13.44S80.99 39.2 80.99 47.18c0 7.9 5.79 13.44 12.51 13.44s12.51-5.55 12.51-13.44z"
    />
    <path
      fill="#FBBC05"
      d="M163.75 47.18c0 12.77-9.99 22.18-22.25 22.18s-22.25-9.41-22.25-22.18c0-12.85 9.99-22.18 22.25-22.18s22.25 9.32 22.25 22.18zm-9.74 0c0-7.98-5.79-13.44-12.51-13.44s-12.51 5.46-12.51 13.44c0 7.9 5.79 13.44 12.51 13.44s12.51-5.55 12.51-13.44z"
    />
    <path
      fill="#4285F4"
      d="M209.75 26.34v39.82c0 16.38-9.66 23.07-21.08 23.07-10.75 0-17.22-7.19-19.66-13.07l8.48-3.53c1.51 3.61 5.21 7.87 11.17 7.87 7.31 0 11.84-4.51 11.84-13v-3.19h-.34c-2.18 2.69-6.38 5.04-11.68 5.04-11.09 0-21.25-9.66-21.25-22.09 0-12.52 10.16-22.26 21.25-22.26 5.29 0 9.49 2.35 11.68 4.96h.34v-3.61h9.25zm-8.56 20.92c0-7.81-5.21-13.52-11.84-13.52-6.72 0-12.35 5.71-12.35 13.52 0 7.73 5.63 13.36 12.35 13.36 6.63 0 11.84-5.63 11.84-13.36z"
    />
    <path fill="#34A853" d="M225 3v65h-9.5V3h9.5z" />
    <path
      fill="#EA4335"
      d="M262.02 54.48l7.56 5.04c-2.44 3.61-8.32 9.83-18.48 9.83-12.6 0-22.01-9.74-22.01-22.18 0-13.19 9.49-22.18 20.92-22.18 11.51 0 17.14 9.16 18.98 14.11l1.01 2.52-29.65 12.28c2.27 4.45 5.8 6.72 10.75 6.72 4.96 0 8.4-2.44 10.92-6.14zm-23.27-7.98l19.82-8.23c-1.09-2.77-4.37-4.7-8.23-4.7-4.95 0-11.84 4.37-11.59 12.93z"
    />
    <path
      fill="#4285F4"
      d="M35.29 41.41V32H67c.31 1.64.47 3.58.47 5.68 0 7.06-1.93 15.79-8.15 22.01-6.05 6.3-13.78 9.66-24.02 9.66C16.32 69.35.36 53.79.36 34.85S16.32.36 35.3.36c10.5 0 17.98 4.12 23.6 9.49l-6.64 6.64c-4.03-3.78-9.49-6.72-16.97-6.72-13.86 0-24.7 11.17-24.7 25.03 0 13.86 10.84 25.03 24.7 25.03 8.99 0 14.11-3.61 17.39-6.89 2.66-2.66 4.41-6.46 5.1-11.65l-22.49.12z"
    />
  </svg>
);

// Google Multicolor "G" Logo
export const GoogleGLogo: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 24 24" className={className} aria-label="Google">
    <path
      fill="#4285F4"
      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
    />
    <path
      fill="#34A853"
      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
    />
    <path
      fill="#FBBC05"
      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.16 0 9.98 0 12s.45 3.84 1.25 5.42l4.03-3.15z"
    />
    <path
      fill="#EA4335"
      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
    />
  </svg>
);

export const PosterPreview: React.FC<PosterPreviewProps> = ({
  businessData,
  posterRef,
  className = '',
  isExportVariant = false,
}) => {
  const [mainQrUrl, setMainQrUrl] = useState<string>('');
  const [mainQrError, setMainQrError] = useState<string | null>(null);
  const [instaQrUrl, setInstaQrUrl] = useState<string>('');
  const [webQrUrl, setWebQrUrl] = useState<string>('');

  const theme = POSTER_THEMES[businessData.theme] || POSTER_THEMES['classic-slate'];

  // Independent QR generation for each code
  useEffect(() => {
    let isCancelled = false;

    async function generateAllQrsIndependently() {
      // 1. Generate Main Google Review QR with high error correction ('H') for center G badge
      try {
        const reviewUrl = getReviewUrl(businessData);
        const mainQr = await generateQrDataUrl(reviewUrl, {
          width: isExportVariant ? 1600 : 700,
          margin: 2,
          color: {
            dark: '#000000',
            light: '#FFFFFF',
          },
          errorCorrectionLevel: 'H',
        });

        if (!isCancelled) {
          setMainQrUrl(mainQr);
          setMainQrError(null);
        }
      } catch (err: any) {
        console.error('Failed to generate main review QR:', err);
        if (!isCancelled) {
          setMainQrError('Failed to generate QR code.');
        }
      }

      // 2. Generate Instagram QR (OPTIONAL)
      if (businessData.showInstagram && isValidUrl(businessData.instagramUrl)) {
        try {
          const instaQr = await generateQrDataUrl(businessData.instagramUrl!.trim(), {
            width: isExportVariant ? 600 : 300,
            margin: 2,
            color: {
              dark: '#000000',
              light: '#FFFFFF',
            },
            errorCorrectionLevel: 'M',
          });
          if (!isCancelled) {
            setInstaQrUrl(instaQr);
          }
        } catch (err: any) {
          console.warn('Optional Instagram QR skipped:', err);
          if (!isCancelled) setInstaQrUrl('');
        }
      } else {
        if (!isCancelled) setInstaQrUrl('');
      }

      // 3. Generate Website QR (OPTIONAL)
      if (businessData.showWebsite && isValidUrl(businessData.websiteUrl)) {
        try {
          const webQr = await generateQrDataUrl(businessData.websiteUrl!.trim(), {
            width: isExportVariant ? 600 : 300,
            margin: 2,
            color: {
              dark: '#000000',
              light: '#FFFFFF',
            },
            errorCorrectionLevel: 'M',
          });
          if (!isCancelled) {
            setWebQrUrl(webQr);
          }
        } catch (err: any) {
          console.warn('Optional Website QR skipped:', err);
          if (!isCancelled) setWebQrUrl('');
        }
      } else {
        if (!isCancelled) setWebQrUrl('');
      }
    }

    generateAllQrsIndependently();

    return () => {
      isCancelled = true;
    };
  }, [
    businessData.name,
    businessData.category,
    businessData.description,
    businessData.googleReviewUrl,
    businessData.instagramUrl,
    businessData.websiteUrl,
    businessData.theme,
    businessData.headline,
    businessData.showInstagram,
    businessData.showWebsite,
    businessData.suggestions,
    isExportVariant,
  ]);

  const showInsta = Boolean(
    businessData.showInstagram && isValidUrl(businessData.instagramUrl) && instaQrUrl
  );
  const showWeb = Boolean(
    businessData.showWebsite && isValidUrl(businessData.websiteUrl) && webQrUrl
  );
  const hasBottomQrs = showInsta || showWeb;

  // Extract clean handle for Instagram
  const instagramHandle = businessData.instagramUrl
    ? businessData.instagramUrl
        .replace(/^https?:\/\/(www\.)?instagram\.com\/?/, '@')
        .replace(/\/$/, '')
    : '@instagram';

  // Extract clean domain for Website
  const cleanWebsiteDomain = businessData.websiteUrl
    ? businessData.websiteUrl.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '')
    : 'website.com';

  // Dynamic responsive font sizes to accommodate long headings and long names
  const headline = businessData.headline || 'CHECK US OUT ON GOOGLE';
  const businessName = businessData.name || 'CAZZ CAFE';

  if (isExportVariant) {
    // ----------------------------------------------------
    // DEDICATED HIGH-RES FIXED-SIZE EXPORT VARIANT (800x1040px)
    // ----------------------------------------------------
    return (
      <div
        ref={posterRef}
        className={`relative w-[800px] min-h-[1040px] bg-white flex flex-col justify-between items-center select-none shadow-none rounded-[36px] border border-slate-200 p-10 box-border ${className}`}
        style={{
          backgroundColor: '#FFFFFF',
          color: '#202124',
          fontFamily: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
        }}
      >
        {/* Top Google 4-Color Branding Strip */}
        <div className="absolute top-0 inset-x-0 h-3.5 flex rounded-t-[36px] overflow-hidden">
          <div className="flex-1 bg-[#4285F4]" />
          <div className="flex-1 bg-[#EA4335]" />
          <div className="flex-1 bg-[#FBBC05]" />
          <div className="flex-1 bg-[#34A853]" />
        </div>

        {/* TOP SECTION: Google Wordmark, Heading & 5 Stars */}
        <div className="w-full flex flex-col items-center text-center pt-2">
          {/* Official Google Multicolor Wordmark */}
          <div className="mb-3 flex items-center justify-center">
            <GoogleWordmark className="h-10 w-auto" />
          </div>

          {/* Heading */}
          <h2
            className={`font-black uppercase tracking-tight text-[#202124] max-w-[90%] leading-snug break-words ${
              headline.length > 35 ? 'text-xl' : 'text-2xl'
            }`}
          >
            {headline}
          </h2>

          {/* 5 Golden Stars */}
          <div className="mt-3 flex items-center justify-center gap-2 text-[#FBBC04]">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-8 h-8 fill-current stroke-current" />
            ))}
          </div>
        </div>

        {/* CENTER SECTION: Main QR with Google 4-Color Border & Center G */}
        <div className="w-full flex flex-col items-center justify-center my-auto py-3">
          {/* Thick Google 4-Color Border */}
          <div
            className="p-[8px] rounded-[36px] shadow-lg flex items-center justify-center bg-gradient-to-tr from-[#34A853] via-[#FBBC05] via-[#EA4335] to-[#4285F4]"
            style={{ width: '360px', height: '360px' }}
          >
            <div className="w-full h-full bg-white rounded-[28px] p-5 flex items-center justify-center relative">
              {mainQrUrl ? (
                <div className="relative w-full h-full flex items-center justify-center">
                  <img
                    src={mainQrUrl}
                    alt="Scan to review us on Google"
                    className="w-full h-full object-contain rounded-xl block"
                  />
                  {/* Center Multicolor G Badge */}
                  <div className="absolute inset-0 m-auto w-16 h-16 bg-white rounded-full shadow-md border border-slate-100 flex items-center justify-center p-2 pointer-events-none">
                    <GoogleGLogo className="w-10 h-10" />
                  </div>
                </div>
              ) : (
                <div className="w-full h-full bg-slate-100 rounded-xl" />
              )}
            </div>
          </div>

          {/* Business Name */}
          <div className="mt-5 text-center flex flex-col items-center max-w-[85%]">
            <h3
              className={`font-black text-[#202124] tracking-tight uppercase leading-tight break-words ${
                businessName.length > 28 ? 'text-2xl' : 'text-3xl'
              }`}
            >
              {businessName}
            </h3>
            {businessData.showCategory && businessData.category && (
              <span className="text-sm font-bold text-slate-500 uppercase tracking-wider mt-1.5">
                {businessData.category}
              </span>
            )}
          </div>
        </div>

        {/* BOTTOM SECTION: Social QRs */}
        <div className="w-full pt-4 border-t border-slate-100">
          {hasBottomQrs ? (
            <div
              className={`w-full flex items-center gap-6 ${
                showInsta && showWeb ? 'justify-between' : 'justify-center'
              }`}
            >
              {/* Instagram QR */}
              {showInsta && (
                <div className="flex items-center gap-4 text-left">
                  <div className="p-[2.5px] rounded-2xl bg-gradient-to-tr from-[#F58529] via-[#DD2A7B] to-[#8134AF] shadow-2xs shrink-0">
                    <div className="bg-white p-1.5 rounded-[13px]">
                      <img
                        src={instaQrUrl}
                        alt="Instagram QR"
                        className="w-16 h-16 object-contain rounded-lg"
                      />
                    </div>
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1.5 text-base font-bold text-slate-900 leading-tight">
                      <Instagram className="w-5 h-5 text-[#E1306C]" />
                      <span>Follow us on Instagram</span>
                    </div>
                    <span className="text-sm font-semibold text-slate-500 truncate max-w-[200px] mt-1">
                      {instagramHandle}
                    </span>
                  </div>
                </div>
              )}

              {/* Website QR */}
              {showWeb && (
                <div
                  className={`flex items-center gap-4 ${
                    showInsta ? 'text-right' : 'text-left'
                  }`}
                >
                  {showInsta && (
                    <div className="flex flex-col">
                      <div className="flex items-center justify-end gap-1.5 text-base font-bold text-slate-900 leading-tight">
                        <Globe className="w-5 h-5 text-[#1A73E8]" />
                        <span>Visit our website</span>
                      </div>
                      <span className="text-sm font-semibold text-slate-500 truncate max-w-[200px] mt-1">
                        {cleanWebsiteDomain}
                      </span>
                    </div>
                  )}

                  <div className="p-[2.5px] rounded-2xl bg-blue-500 shadow-2xs shrink-0">
                    <div className="bg-white p-1.5 rounded-[13px]">
                      <img
                        src={webQrUrl}
                        alt="Website QR"
                        className="w-16 h-16 object-contain rounded-lg"
                      />
                    </div>
                  </div>

                  {!showInsta && (
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1.5 text-base font-bold text-slate-900 leading-tight">
                        <Globe className="w-5 h-5 text-[#1A73E8]" />
                        <span>Visit our website</span>
                      </div>
                      <span className="text-sm font-semibold text-slate-500 truncate max-w-[200px] mt-1">
                        {cleanWebsiteDomain}
                      </span>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="w-full text-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                Review us on Google
              </span>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ----------------------------------------------------
  // RESPONSIVE LIVE PREVIEW VARIANT (Adaptive Fluid Container)
  // ----------------------------------------------------
  const headlineClass =
    headline.length > 38
      ? 'text-xs sm:text-[13px]'
      : headline.length > 24
      ? 'text-[13px] sm:text-sm'
      : 'text-sm sm:text-base';

  const nameClass =
    businessName.length > 30
      ? 'text-xs sm:text-sm'
      : businessName.length > 18
      ? 'text-sm sm:text-base'
      : 'text-base sm:text-lg';

  return (
    <div
      ref={posterRef}
      className={`relative w-full max-w-[390px] min-h-[490px] sm:min-h-[510px] bg-white flex flex-col justify-between items-center select-none shadow-xl rounded-3xl border border-slate-200/90 transition-all duration-300 pt-6 pb-5 px-5 sm:px-6 sm:pt-7 sm:pb-6 box-border ${className}`}
      style={{
        backgroundColor: '#FFFFFF',
        color: '#202124',
        fontFamily: "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
      }}
    >
      {/* Top Google 4-Color Branding Strip */}
      <div className="absolute top-0 inset-x-0 h-2 flex rounded-t-3xl overflow-hidden">
        <div className="flex-1 bg-[#4285F4]" />
        <div className="flex-1 bg-[#EA4335]" />
        <div className="flex-1 bg-[#FBBC05]" />
        <div className="flex-1 bg-[#34A853]" />
      </div>

      {/* TOP SECTION: Google Wordmark, Heading & 5 Stars */}
      <div className="w-full flex flex-col items-center text-center pt-0.5">
        {/* Official Google Multicolor Logo */}
        <div className="mb-2 flex items-center justify-center">
          <GoogleWordmark className="h-6 sm:h-6.5 w-auto" />
        </div>

        {/* Business-Specific Heading */}
        <h2
          className={`font-black uppercase tracking-tight text-[#202124] max-w-[94%] leading-snug break-words ${headlineClass}`}
        >
          {headline}
        </h2>

        {/* 5 GOLDEN STARS DIRECTLY ABOVE QR */}
        <div className="mt-2 flex items-center justify-center gap-1.5 text-[#FBBC04]">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className="w-5 h-5 sm:w-5.5 sm:h-5.5 fill-current stroke-current drop-shadow-2xs"
            />
          ))}
        </div>
      </div>

      {/* CENTER SECTION: Main QR with Thick Google 4-Color Border & Center G */}
      <div className="w-full flex flex-col items-center justify-center my-auto py-1">
        {/* Thick Google 4-Color Border (5.5px thick) */}
        <div
          className="p-[5.5px] rounded-3xl shadow-md transition-all flex items-center justify-center bg-gradient-to-tr from-[#34A853] via-[#FBBC05] via-[#EA4335] to-[#4285F4]"
          style={{
            maxWidth: '210px',
            width: '100%',
          }}
        >
          {/* Inner Clean White Container (Quiet Zone) */}
          <div className="w-full aspect-square bg-white rounded-[19px] p-2.5 sm:p-3 flex items-center justify-center relative">
            {mainQrUrl ? (
              <div className="relative w-full h-full flex items-center justify-center">
                <img
                  src={mainQrUrl}
                  alt="Scan to review us on Google"
                  className="w-full h-full object-contain rounded-lg block"
                />

                {/* Center Badge with Official Multicolor Google "G" */}
                <div className="absolute inset-0 m-auto w-9 h-9 sm:w-10 sm:h-10 bg-white rounded-full shadow-md border border-slate-100 flex items-center justify-center p-1.5 pointer-events-none">
                  <GoogleGLogo className="w-5 h-5 sm:w-6 sm:h-6" />
                </div>
              </div>
            ) : mainQrError ? (
              <div className="p-2 text-center text-xs text-rose-500 font-medium">
                {mainQrError}
              </div>
            ) : (
              <div className="w-full h-full bg-slate-100 animate-pulse rounded-lg" />
            )}
          </div>
        </div>

        {/* Business Name */}
        <div className="mt-3 text-center flex flex-col items-center max-w-[92%]">
          <h3
            className={`font-black text-[#202124] tracking-tight uppercase leading-tight break-words ${nameClass}`}
          >
            {businessName}
          </h3>
          {businessData.showCategory && businessData.category && (
            <span className="text-[10px] sm:text-[11px] font-bold text-slate-500 uppercase tracking-wider mt-0.5">
              {businessData.category}
            </span>
          )}
        </div>
      </div>

      {/* BOTTOM SECTION: Social QRs */}
      <div className="w-full pt-1">
        {hasBottomQrs ? (
          <div
            className={`w-full flex items-center gap-3 ${
              showInsta && showWeb ? 'justify-between' : 'justify-center'
            }`}
          >
            {/* Instagram QR */}
            {showInsta && (
              <div className="flex items-center gap-2 sm:gap-2.5 text-left">
                <div className="p-[1.5px] rounded-xl bg-gradient-to-tr from-[#F58529] via-[#DD2A7B] to-[#8134AF] shadow-2xs shrink-0">
                  <div className="bg-white p-1 rounded-[10px]">
                    <img
                      src={instaQrUrl}
                      alt="Instagram QR"
                      className="w-10 h-10 sm:w-11 sm:h-11 object-contain rounded-md"
                    />
                  </div>
                </div>

                <div className="flex flex-col">
                  <div className="flex items-center gap-1 text-[10px] sm:text-[11px] font-bold text-slate-900 leading-tight">
                    <Instagram className="w-3 h-3 text-[#E1306C]" />
                    <span>Follow us</span>
                  </div>
                  <span className="text-[9px] sm:text-[10px] font-semibold text-slate-500 truncate max-w-[100px] sm:max-w-[125px] mt-0.5">
                    {instagramHandle}
                  </span>
                </div>
              </div>
            )}

            {/* Website QR */}
            {showWeb && (
              <div
                className={`flex items-center gap-2 sm:gap-2.5 ${
                  showInsta ? 'text-right' : 'text-left'
                }`}
              >
                {showInsta && (
                  <div className="flex flex-col">
                    <div className="flex items-center justify-end gap-1 text-[10px] sm:text-[11px] font-bold text-slate-900 leading-tight">
                      <Globe className="w-3 h-3 text-[#1A73E8]" />
                      <span>Website</span>
                    </div>
                    <span className="text-[9px] sm:text-[10px] font-semibold text-slate-500 truncate max-w-[100px] sm:max-w-[125px] mt-0.5">
                      {cleanWebsiteDomain}
                    </span>
                  </div>
                )}

                <div className="p-[1.5px] rounded-xl bg-blue-500 shadow-2xs shrink-0">
                  <div className="bg-white p-1 rounded-[10px]">
                    <img
                      src={webQrUrl}
                      alt="Website QR"
                      className="w-10 h-10 sm:w-11 sm:h-11 object-contain rounded-md"
                    />
                  </div>
                </div>

                {!showInsta && (
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1 text-[10px] sm:text-[11px] font-bold text-slate-900 leading-tight">
                      <Globe className="w-3 h-3 text-[#1A73E8]" />
                      <span>Visit our website</span>
                    </div>
                    <span className="text-[9px] sm:text-[10px] font-semibold text-slate-500 truncate max-w-[130px] mt-0.5">
                      {cleanWebsiteDomain}
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="w-full text-center">
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">
              Review us on Google
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
