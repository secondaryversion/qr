import React from 'react';
import { AlertTriangle, ArrowLeft, Sparkles, QrCode } from 'lucide-react';

interface InvalidReviewPageProps {
  onGoToGenerator: () => void;
  onLoadDemo: () => void;
}

export const InvalidReviewPage: React.FC<InvalidReviewPageProps> = ({
  onGoToGenerator,
  onLoadDemo,
}) => {
  return (
    <div className="min-h-screen w-full bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-3xl p-7 shadow-xl border border-slate-100 text-center flex flex-col items-center">
        <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4">
          <AlertTriangle className="w-8 h-8" />
        </div>

        <h1 className="text-xl font-bold text-slate-900 mb-2">
          Sorry, this review QR is invalid or incomplete.
        </h1>

        <p className="text-xs text-slate-500 mb-6 leading-relaxed">
          The link appears to be missing some business data. Please re-scan the QR code or create a new review card in the generator.
        </p>

        <div className="w-full space-y-2.5">
          <button
            onClick={onGoToGenerator}
            className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Go to ReviewQR Generator</span>
          </button>

          <button
            onClick={onLoadDemo}
            className="w-full py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-all flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Try Sample Demo Experience</span>
          </button>
        </div>
      </div>
    </div>
  );
};
