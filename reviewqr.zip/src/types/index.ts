export type PosterThemeId = 
  | 'classic-slate'
  | 'warm-ochre'
  | 'emerald-luxury'
  | 'royal-indigo'
  | 'minimal-mono';

export interface PosterTheme {
  id: PosterThemeId;
  name: string;
  tagline: string;
  bgGradient: string;
  bgSolid: string;
  cardBg: string;
  borderColor: string;
  accentColor: string;
  accentLight: string;
  textColor: string;
  textMuted: string;
  qrFg: string;
  qrBg: string;
  badgeBg: string;
  badgeText: string;
  buttonGradient: string;
}

export interface ReviewSuggestion {
  id: string;
  style: 'Short & Simple' | 'Friendly' | 'Detailed' | 'Highly Recommended' | string;
  text: string;
}

export interface BusinessData {
  name: string;
  category: string;
  description: string;
  googleReviewUrl: string;
  instagramUrl?: string;
  websiteUrl?: string;
  logo?: string; // Base64 data URL
  theme: PosterThemeId;
  headline: string;
  subheadline?: string;
  showLogo: boolean;
  showInstagram: boolean;
  showWebsite: boolean;
  showCategory: boolean;
  suggestions: ReviewSuggestion[];
}

export interface EncodedReviewData {
  n: string; // name
  c: string; // category
  d: string; // description
  g: string; // googleReviewUrl
  i?: string; // instagramUrl
  w?: string; // websiteUrl
  t: PosterThemeId; // theme
  h?: string; // headline
  s: Array<{ s: string; t: string }>; // style, text
  l?: string; // optional lightweight logo
}
